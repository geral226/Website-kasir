<h4 class="text-center">Daftar Menu</h4>
<a href="tambah-order.php" class="btn btn-primary">Pesan Sekarang</a>
<a href="tambah-menu.php" class="btn btn-primary">Tambah Menu</a>
<hr> 
<div class="table-responsive" id="cari_menu">
    <table class="table table-stripped table-bordered">
        <thead class="table-light">
            <tr>
                <th class="text-center">Nama Masakan</th>
                <th class="text-center">Harga</th>
                <th class="text-center">Status Makanan</th>
                <th class="text-center">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            include "../koneksi.php";
            $sql = mysqli_query($koneksi, "SELECT * FROM masakan");
            $no = 1;
            while ($data = mysqli_fetch_array($sql)) {
            ?>
                <tr>
                    <td class="text-center">
                        <h5 class="font-size-14 text-truncate">
                            <a href="#" class="text-dark" data-id="<?php echo $data['id_masakan']; ?>"><?php echo $data["nama_masakan"]; ?></a>
                        </h5>
                    </td>
                    <td class="text-center"><?php echo $data["harga"]; ?></td>
                    <td class="text-center">
                        <?php
                        if ($data["status_makanan"] == "Tersedia") {
                            $status = "Tersedia";
                            $warna = "badge bg-success";
                        } elseif ($data["status_makanan"] == "Habis") {
                            $status = "Habis";
                            $warna = "badge bg-warning";
                        } else {
                            $status = "Status Tidak Valid";
                            $warna = "badge bg-danger";
                        }
                        ?>
                        <span class="badge <?php echo $warna; ?> font-size-12"><?php echo $status; ?></span>
                    </td>
                        <td><a href="?url=edit-menu&id_masakan=<?= $data['id_masakan']?>" class="btn btn-primary">Edit</a></td>
                    <td><a href="?url=hapus-menu&id_masakan=<?= $data['id_masakan']?>" class="btn btn-danger" onClick="return confirm('Apakah anda ingin menghapus menu <?php echo $data['nama_masakan']; ?>?')">Hapus</a></td>
                  </tr>
                </tr>
            <?php
                $no++;
            }
            ?>
        </tbody>
    </table>
</div>