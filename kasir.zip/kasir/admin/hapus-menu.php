<?php 
include "../koneksi.php";
$id_masakan = $_GET['id_masakan'];
$sql = mysqli_query($koneksi,"DELETE FROM masakan WHERE id_masakan='$id_masakan'");
if($sql){
	echo "<script>
	alert('Data berhasil dihapus!')
	document.location.href='admin.php'</script>\n";
}else{
	echo "<script>
	alert('Data gagal dihapus!')
	</script>";
}
 ?>