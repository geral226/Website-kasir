 <?php
include "../koneksi.php";
?>
<form method="POST" action="?url=tambah-masakan">
<h5>History Pesanan</h5>
<table class="table table-striped table-bordered">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama Masakan</th>
            <th>Tanggal</th>
            <th>Jumlah</th>
            <th>Metode Pembayaran</th>
            <th>Status Pembayaran</th>
            <th>Total Bayar</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $sql = mysqli_query($koneksi, "SELECT * FROM pesanan");
        $no = 1;
        while ($data = mysqli_fetch_array($sql)) {
        ?>
            <tr>
                <td><?php echo $no; ?></td>
                <td><?php echo $data['nama_masakan']; ?></td>
                <td><?php echo $data['waktu_pesan']; ?></td>
                <td><?php echo $data['jumlah']; ?></td>
                <td><?php echo $data['metode_pembayaran']; ?></td>
                <td><?php echo $data['status_pembayaran']; ?></td>
                 <td><?php echo $data['total_bayar']; ?></td>
            </tr>
        <?php $no++;
        } ?>
    </tbody>
</table>
</form>