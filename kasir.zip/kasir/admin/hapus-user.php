<?php 
include "../koneksi.php";
$id_user = $_GET['id_user'];
$sql = mysqli_query($koneksi,"DELETE FROM user WHERE id_user='$id_user'");
if($sql){
	echo "<script>
	alert('Data berhasil dihapus!')
	document.location.href='admin.php'</script>\n";
}else{
	echo "<script>
	alert('Data gagal dihapus!')
	</script>";
}
 ?>