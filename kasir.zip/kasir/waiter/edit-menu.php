<?php 
$id_masakan = $_GET['id_masakan'];
include "../koneksi.php";
$sql = mysqli_query($koneksi,"SELECT * FROM masakan WHERE id_masakan = '$id_masakan'");
$data = mysqli_fetch_array($sql)
 ?>
<h5>Halaman Edit Menu</h5>
<hr>
<form method="post" action="?url=edit-menu&id_masakan=<?= $id_masakan; ?>">
	<div class="form-group mb-2">
		<label>Id Makanan</label>
		<input value ="<?= $data['id_masakan'] ?>" type="number" name="id_masakan"  class="form-control" required>
	</div>
	<div class="form-group mb-2">
		<label>Nama Makanan</label>
		<input value ="<?= $data['nama_masakan'] ?>" type="text" name="nama_masakan"  class="form-control" required>
	</div>
	<div class="form-group mb-2">
		<label>Harga</label>
		<input value ="<?= $data['harga'] ?>" type="number" name="harga"  class="form-control" required>
	</div>
<div class="form-group mb-2">
		<label>Status Makanan</label>
		<select value ="<?= $data['status_makanan'] ?>" name="status_makanan" class="form-control" required>
			<option></option>
            <option>Tersedia</option>
            <option>Habis</option>
        </select>
	</div>
	<div class="form-group">
		<button type="submit" class="btn btn-primary" name="submit">Simpan</button>
		<button type="reset" class="btn btn-warning">Kosongkan</button>
	</div>
</form>
<?php 
include "../koneksi.php";
if(isset($_POST['submit'])){
	$id_masakan 		= $_POST['id_masakan'];
	$nama_masakan 		= $_POST['nama_masakan'];
	$harga 				= $_POST['harga'];
	$status_makanan	 	= $_POST['status_makanan'];
$sql = mysqli_query($koneksi,"UPDATE masakan SET id_masakan = '$id_masakan', nama_masakan = '$nama_masakan', harga = '$harga', status_makanan = '$status_makanan' WHERE id_masakan='$id_masakan'");

if($sql){
	echo "<script>
	alert('Data berhasil Disimpan!')
	window.location.assign('?url=masakan')
	</script>";
}else{
	echo "<script>
	alert('Data gagal Disimpan!')
	</script>";
}
}
 ?>