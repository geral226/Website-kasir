<h5>Tambah Menu</h5>
<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
<a href="waiter.php" class="btn btn-primary">Kembali</a><hr>
<form method="POST" action="?url=tambah-menu">
    <div class="form-group mb-2">
        <label>Id Makanan</label>
        <input type="number" name="id_masakan" maxlength="11" class="form-control" required>
    </div>
    <div class="form-group mb-2">
        <label>Nama Makanan</label>
        <input type="text" name="nama_masakan" maxlength="13" class="form-control" required>
    </div>
    <div class="form-group mb-2">
        <label>Harga</label>
        <input type="number" name="harga" maxlength="13" class="form-control" required>
    </div>
    <div class="form-group mb-2">
        <label>Status Makanan</label>
        <select name="status_makanan" class="form-control" required>
            <option></option>
            <option>Tersedia</option>
            <option>Habis</option>
        </select>
    </div>
    <div class="form-group">
        <button type="submit" class="btn btn-primary" name="submit">Kirim</button>
        <button type="reset" class="btn btn-warning" name="reset">Reset</button>
    </div>
    <?php
include "../koneksi.php";
if (isset($_POST['submit'])){
    $id_masakan       = $_POST['id_masakan'];
    $nama_masakan     = $_POST['nama_masakan'];
    $harga            = $_POST['harga'];
    $status_makanan   = $_POST['status_makanan'];
    $query = mysqli_query($koneksi, "INSERT INTO masakan (id_masakan, nama_masakan, harga, status_makanan) 
        VALUES ('$id_masakan', '$nama_masakan', '$harga', '$status_makanan')");
    if ($query){
     echo "<script>alert('Data Berhasil Disimpan');
        document.location.href='waiter.php'</script>\n";
    } else {
        echo "<script>alert('Data Gagal Disimpan');
        document.location.href='tambah-menu.php'</script>\n";
    }
}
?>
</form>