<h5>Tambah User</h5>
<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
<a href="waiter.php" class="btn btn-primary">Kembali</a><hr>
<form method="POST" action="?url=tambah-user">
    <div class="form-group mb-2">
        <label>Id User</label>
        <input type="number" name="id_user" maxlength="11" class="form-control" required>
    </div>
    <div class="form-group mb-2">
        <label>Username</label>
        <input type="text" name="username" maxlength="13" class="form-control" required>
    </div>
    <div class="form-group mb-2">
        <label>Password</label>
        <input type="password" name="password" maxlength="13" class="form-control" required>
    </div>
    <div class="form-group mb-2">
        <label>Nama User</label>
        <input type="text" name="nama_user" maxlength="13" class="form-control" required>
    </div>
     <div class="form-group mb-2">
        <label>Id Level</label>
        <select name="id_level" class="form-control" required>
            <option></option>
            <option>1</option>
            <option>2</option>
            <option>3</option>
            <option>4</option>
            <option>5</option>
        </select>
    </div>
    <div class="form-group">
        <button type="submit" class="btn btn-primary" name="submit">Kirim</button>
        <button type="reset" class="btn btn-warning" name="reset">Reset</button>
    </div>
    <?php
include "../koneksi.php";
if (isset($_POST['submit'])){
    $id_user    = $_POST['id_user'];
    $username   = $_POST['username'];
    $password   = $_POST['password'];
    $nama_user  = $_POST['nama_user'];
    $id_level   = $_POST['id_level'];
    $query = mysqli_query($koneksi, "INSERT INTO user (id_user, username, password, nama_user, id_level) 
        VALUES ('$id_user', '$username', '$password', '$nama_user', '$id_level')");
    if ($query){
        echo "<script>alert('Data Berhasil Disimpan');
        document.location.href='waiter.php'</script>\n";
    } else {
        echo "<script>alert('Data Gagal Disimpan');
        document.location.href='tambah-user.php'</script>\n";
    }
}
?>
</form>