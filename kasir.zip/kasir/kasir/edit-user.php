<?php 
$id_user = $_GET['id_user'];
include "../koneksi.php";
$sql = mysqli_query($koneksi,"SELECT * FROM user WHERE id_user = '$id_user'");
$data = mysqli_fetch_array($sql)
 ?>
<h5>Halaman Edit Petugas</h5>
<hr>
<form method="post" action="?url=edit-user&id_user=<?= $id_user; ?>">
	<div class="form-group mb-2">
		<label>Id User</label>
		<input value ="<?= $data['id_user'] ?>" type="text" name="id_user"  class="form-control" required>
	</div>
	<div class="form-group mb-2">
		<label>Username</label>
		<input value ="<?= $data['username'] ?>" type="text" name="username"  class="form-control" required>
	</div>
	<div class="form-group mb-2">
		<label>Password</label>
		<input value ="<?= $data['password'] ?>" type="text" name="password"  class="form-control" required>
	</div>
	<div class="form-group mb-2">
		<label>Nama User</label>
		<input value ="<?= $data['nama_user'] ?>" type="text" name="nama_user"  class="form-control" required>
	</div>
	<div class="form-group mb-2">
		<label>Id level</label>
		<select value ="<?= $data['id_level'] ?>" name="id_level" class="form-control" required>
			<option></option>
            <option>1</option>
            <option>2</option>
            <option>3</option>
            <option>4</option>
            <option>5</option>
        </select>
	</div>
	<div class="form-group">
		<button type="submit" class="btn btn-primary" name="submit">Simpan</button>
		<button type="reset" class="btn btn-warning">Kosongkan</button>
	</div>
</form>
<?php 
include "../koneksi.php";
if(isset($_POST['submit'])){
	$id_user 		= $_POST['id_user'];
	$username 		= $_POST['username'];
	$password 		= $_POST['password'];
	$nama_user	 	= $_POST['nama_user'];
	$id_level 		= $_POST['id_level'];
$sql = mysqli_query($koneksi,"UPDATE user SET id_user = '$id_user', username = '$username', password = '$password', nama_user = '$nama_user', id_level = '$id_level' WHERE id_user='$id_user'");
if($sql){
	echo "<script>
	alert('Data berhasil Disimpan!')
	window.location.assign('?url=registrasi')
	</script>";
}else{
	echo "<script>
	alert('Data gagal Disimpan!')
	</script>";
}
}
 ?>