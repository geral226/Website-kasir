<?php 
session_start();
if($_SESSION['id_level'] != '2'){
	echo "<script> alert('Maaf anda bukan kasir! silahkan login terlebih dahulu!')
	window.location.assign('../index.php')
	</script>";
	}
 ?>
 <?php 
 include "../koneksi.php";
 $sql = mysqli_query($koneksi,"SELECT * FROM user ");
 $data = mysqli_fetch_array($sql);
  ?>
<!DOCTYPE html>
<html>
<head>
	<title>Ral's</title>
	<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
</head>
<body>
	<div class="container mt-5">
		<h3>Aplikasi Ral's</h3>
		<div class="alert alert-info">
			Selamat Datang, <b><?php echo $_SESSION['nama_user']; ?>(<?php echo $_SESSION['id_level']; ?>)</b> di Aplikasi Ral's
		</div>
		<a href="kasir.php" class="btn btn-primary">administrator</a>
		<a href="kasir.php?url=registrasi" class="btn btn-primary">Registrasi</a>
		<a href="kasir.php?url=masakan" class="btn btn-primary">Menu</a>	
		<a href="kasir.php?url=pemesanan" class="btn btn-primary">History Pesanan</a>
		<a href="logout.php?url=logout" class="btn btn-danger">Logout</a>
		<div class="card mt-5">
			<div class="card-body">
			<?php 
			$file = @$_GET['url'];
			if(empty($file)){
				echo "<h4>Selamat datang di Halaman administrtor!</h4>";
				echo "Aplikasi Ral's digunakan untuk mempermudah pembayaran pelanggan";
			}else{
				include $file.'.php';
			}
			 ?>
			</div>
		</div>
	</div>
<script type="text/javascript" src="../bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>