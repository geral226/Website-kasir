<h5>Order</h5>
<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
<a href="pelanggan.php" class="btn btn-primary">Kembali</a>
<hr>
<form method="POST" action="?url=tambah-masakan">
    <div class="form-group mb-2">
        <label>Pilih Masakan</label>
        <select name="nama_masakan" class="form-control" required>
            <?php
            include "../koneksi.php";
            $query = mysqli_query($koneksi, "SELECT nama_masakan, harga FROM masakan");
            if ($query) {
                while ($row = mysqli_fetch_assoc($query)) {
                    echo "<option value='" . $row['nama_masakan'] . "' data-harga='" . $row['harga'] . "'>" . $row['nama_masakan'] . "</option>";
                }
            } else {
                echo "<option value=''>Tidak ada masakan</option>";
            }
            ?>
        </select>
    <div class="form-group mb-2">
        <label>Jumlah</label>
        <input type="number" name="jumlah" id="jumlah" min="1" class="form-control" required onchange="hitungTotal()">
    </div>
    <div class="form-group mb-2">
        <label>Metode Pembayaran</label>
        <select name="metode_pembayaran" class="form-control" required>
            <option value="Tunai">Tunai</option>
            <option value="Kartu Kredit">Kartu Kredit</option>
            <option value="Transfer Bank">Transfer Bank</option>
        </select>
    </div>
    <div class="form-group mb-2">
        <label>Status Pembayaran</label>
        <select name="status_pembayaran" class="form-control" required>
            <option value="Belum Lunas">Belum Lunas</option>
            <option value="Lunas">Lunas</option>
        </select>
    </div>
    <div class="form-group mb-2">
        <label>Total Bayar</label>
        <input type="text" name="total_bayar" id="total_bayar" class="form-control" readonly>
    </div>
    <div class="form-group">
        <button type="submit" class="btn btn-primary" name="submit">Kirim</button>
        <button type="reset" class="btn btn-warning" name="reset">Reset</button>
    </div>
</form>
<script>
function hitungTotal() {
    var selectedOption = document.querySelector('select[name="nama_masakan"] option:checked');
    var harga = selectedOption.getAttribute('data-harga');
    var jumlah = document.getElementById('jumlah').value;
    var totalBayar = harga * jumlah;
    document.getElementById('total_bayar').value = totalBayar;
}
</script>
<?php
include "../koneksi.php";
if(isset($_POST['submit'])) {
    $nama_masakan = $_POST['nama_masakan'];
    $jumlah = $_POST['jumlah'];
    $metode_pembayaran = $_POST['metode_pembayaran'];
    $status_pembayaran = $_POST['status_pembayaran'];
    $total_bayar = $_POST['total_bayar'];
    $query = "INSERT INTO pesanan (nama_masakan, jumlah, metode_pembayaran, status_pembayaran, total_bayar) VALUES ('$nama_masakan' ,'$jumlah', '$metode_pembayaran', '$status_pembayaran', '$total_bayar')";
    $result = mysqli_query($koneksi, $query);
    if($result) {
        header("Location: pelanggan.php");
        exit;
    } else {
        echo "Gagal menyimpan data order: " . mysqli_error($koneksi);
    }
}
?>