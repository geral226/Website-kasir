<?php 
session_start();
if($_SESSION['id_level'] != '4'){
	echo "<script> alert('Maaf anda bukan pelanggan! silahkan login terlebih dahulu!')
	window.location.assign('../index.php')
	</script>";
	}
 ?>
 <?php 
 include "../koneksi.php";
 $sql = mysqli_query($koneksi,"SELECT * FROM user ");
 $data = mysqli_fetch_array($sql);
  ?>
<!DOCTYPE html>
<html>
<head>
	<title>Ral's</title>
	<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
</head>
<body>
	<div class="container mt-5">
		<h3>Aplikasi Ral's</h3>
		<div class="alert alert-info">
						Selamat Datang, <b><?php echo $_SESSION['nama_user']; ?>(<?php echo $_SESSION['id_level']; ?>)</b> di aplikasi Ral's
		</div>
		<a href="pelanggan.php" class="btn btn-primary">Hallo</a>
		<a href="pelanggan.php?url=masakan" class="btn btn-primary">Menu</a>
		<a href="logout.php?url=logout" class="btn btn-danger">Logout</a>
		<div class="card mt-5">
			<div class="card-body">
			<?php 
			$file = @$_GET['url'];
			if(empty($file)){
				echo "<h4>Selamat datang di Halaman Ral's!</h4>";
				echo "Yuk order kita lagi ada menu  baru nih jangan sampe ke habisan!!!";
			}else{
				include $file.'.php';
			}
			 ?>
			</div>
		</div>
	</div>
<script type="text/javascript" src="../bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>